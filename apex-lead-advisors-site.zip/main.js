/* ==========================================================
   SITE SETTINGS: edit these values, everything updates.
   ========================================================== */
const SITE = {
  phone: '+27 84 010 1111',       // WhatsApp number shown on the site
  phoneLink: '+27840101111',      // used for tap-to-call
  whatsapp: '27840101111',        // international format, no +
  whatsappText: "Hi Trish, I'd like to chat about getting more leads for my business.",
  email: 'trishta@apexleadadvisors.com',
  calendly: 'https://calendly.com/trishta65',
  // Enquiries from the form are sent through Formspree.
  formEndpoint: 'https://formspree.io/f/mljgjnjy',
  // Used only if formEndpoint is emptied: the form opens the visitor's email app addressed here.
  leadEmail: 'trishta@apexleadadvisors.com',
  // Set by the preview build. Shows the thank-you screen without sending anything.
  preview: false,
};

(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Apply settings
  $$('[data-cfg]').forEach(el => { el.textContent = SITE[el.dataset.cfg]; });
  $$('[data-cfg-href="tel"]').forEach(a => { a.href = `tel:${SITE.phoneLink}`; });
  $$('[data-cfg-href="mailto"]').forEach(a => { a.href = `mailto:${SITE.email}`; });
  $$('[data-cfg-href="wa"]').forEach(a => { a.href = `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(SITE.whatsappText)}`; });
  $$('[data-cfg-href="cal"]').forEach(a => { a.href = SITE.calendly; });
  $$('[data-year]').forEach(el => { el.textContent = new Date().getFullYear(); });

  // Mobile menu
  const toggle = $('.menu-toggle');
  const nav = $('#site-nav');
  const header = $('.header');
  const setMenu = open => {
    document.body.classList.toggle('nav-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    if (open) nav.style.top = `${header.getBoundingClientRect().bottom}px`;
  };
  toggle.addEventListener('click', () => setMenu(!document.body.classList.contains('nav-open')));
  nav.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && document.body.classList.contains('nav-open')) { setMenu(false); toggle.focus(); }
  });

  // Mobile sticky bar appears once the hero form is out of view
  const form = $('#estimate-form');
  const hero = $('.hero');
  new IntersectionObserver(([e]) => {
    document.body.classList.toggle('show-bar', !e.isIntersecting);
  }, { threshold: 0.05 }).observe(hero);

  // Active nav link
  const links = $$('.nav a[href^="#"]:not(.btn)');
  const sections = links.map(a => $(a.getAttribute('href'))).filter(Boolean);
  const navObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) links.forEach(a => a.classList.toggle('is-current', a.getAttribute('href') === `#${e.target.id}`));
    });
  }, { rootMargin: '-45% 0px -50% 0px' });
  sections.forEach(s => navObs.observe(s));

  // Any "free estimate" CTA: scroll to the form, focus the first choice, flash it
  $$('a[href="#estimate"]').forEach(a => a.addEventListener('click', e => {
    e.preventDefault();
    $('#estimate').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    try { history.replaceState(null, '', '#estimate'); } catch (_) {}
    const first = $('.step.is-active input, .step.is-active button', form);
    setTimeout(() => {
      first && first.focus({ preventScroll: true });
      form.classList.remove('is-flash'); void form.offsetWidth; form.classList.add('is-flash');
    }, reduceMotion ? 0 : 450);
  }));

  /* ---------- Estimate form (homepage only) ---------- */
  if (form) {
  const steps = $$('.step', form);
  const bar = $('.progress__bar', form);
  const stepNum = $('[data-step-num]', form);
  const stepLabel = $('.estimate__step', form);

  const show = key => {
    steps.forEach(s => {
      const on = s.dataset.step === key;
      s.hidden = !on;
      s.classList.toggle('is-active', on);
    });
    const n = key === '1' ? 1 : 2;
    bar.style.width = key === 'done' ? '100%' : `${n * 50}%`;
    stepNum.textContent = n;
    stepLabel.hidden = key === 'done';
  };

  const setError = (input, errEl, msg) => {
    errEl.textContent = msg;
    if (input) input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  };

  const errProject = $('#err-project');
  $('[data-next]', form).addEventListener('click', () => {
    const chosen = form.project.value;
    if (!setError(null, errProject, chosen ? '' : 'Please choose your type of business.')) {
      $('input[name="project"]', form).focus();
      return;
    }
    show('2');
    $('#f-name').focus();
  });
  $$('input[name="project"]', form).forEach(r => r.addEventListener('change', () => {
    setError(null, errProject, '');
  }));
  // Double-click / Enter on a tile moves straight on
  $$('.tile', form).forEach(t => t.addEventListener('dblclick', () => $('[data-next]', form).click()));

  $('[data-back]', form).addEventListener('click', () => {
    show('1');
    ($('input[name="project"]:checked', form) || $('input[name="project"]', form)).focus();
  });

  const name = $('#f-name');
  const phone = $('#f-phone');
  const validateName = () => setError(name, $('#err-name'), name.value.trim().length >= 2 ? '' : 'Please enter your name.');
  const validatePhone = () => {
    const digits = phone.value.replace(/\D/g, '');
    return setError(phone, $('#err-phone'), digits.length >= 7 ? '' : 'Please enter a phone number we can call you on (at least 7 digits).');
  };
  name.addEventListener('blur', () => name.value && validateName());
  phone.addEventListener('blur', () => phone.value && validatePhone());
  name.addEventListener('input', () => name.getAttribute('aria-invalid') === 'true' && validateName());
  phone.addEventListener('input', () => phone.getAttribute('aria-invalid') === 'true' && validatePhone());

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if ($('.step[data-step="1"]', form).classList.contains('is-active')) { $('[data-next]', form).click(); return; }
    const okName = validateName();
    const okPhone = validatePhone();
    if (!okName || !okPhone) { (okName ? phone : name).focus(); return; }

    const data = {
      project: form.project.value,
      name: name.value.trim(),
      phone: phone.value.trim(),
      email: form.email.value.trim(),
      business: form.business.value.trim(),
      details: form.details.value.trim(),
    };
    const btn = $('[data-submit]', form);
    btn.classList.add('is-loading'); btn.disabled = true;

    try {
      if (SITE.preview) {
        await new Promise(r => setTimeout(r, 600));
      } else if (SITE.formEndpoint) {
        const res = await fetch(SITE.formEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ ...data, _subject: `New enquiry: ${data.project}${data.business ? ` (${data.business})` : ''}`, ...(data.email ? { _replyto: data.email } : {}) }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
      } else {
        const body = `Business type: ${data.project}\nBusiness name: ${data.business}\nName: ${data.name}\nPhone: ${data.phone}\nEmail: ${data.email}\n\n${data.details}`;
        window.location.href = `mailto:${SITE.leadEmail}?subject=${encodeURIComponent(`New enquiry: ${data.project}`)}&body=${encodeURIComponent(body)}`;
      }
      $('[data-done-name]', form).textContent = data.name.split(' ')[0];
      show('done');
      $('.step--done', form).focus();
    } catch (err) {
      setError(null, $('#err-phone'), `Sorry, something went wrong sending your request. Please try again, or WhatsApp ${SITE.phone}.`);
    } finally {
      btn.classList.remove('is-loading'); btn.disabled = false;
    }
  });

  }

  /* ---------- Gallery video ---------- */
  $$('.g--video').forEach(fig => {
    const video = $('video', fig);
    const btn = $('.g__play', fig);
    const pauseIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';
    const playIcon = btn.innerHTML;
    btn.addEventListener('click', () => {
      if (video.paused) { video.play(); } else { video.pause(); }
    });
    video.addEventListener('play', () => { fig.classList.add('is-playing'); btn.innerHTML = pauseIcon; btn.setAttribute('aria-label', 'Pause video'); });
    video.addEventListener('pause', () => { fig.classList.remove('is-playing'); btn.innerHTML = playIcon; btn.setAttribute('aria-label', 'Play video'); });
  });

})();

/* Portfolio videos: play muted while on screen, pause when scrolled away */
(() => {
  const vids = document.querySelectorAll('.work-card video');
  if (!vids.length || !('IntersectionObserver' in window)) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(({ target, isIntersecting }) => {
      if (isIntersecting) target.play().catch(() => {});
      else target.pause();
    });
  }, { threshold: 0.5 });
  vids.forEach(v => io.observe(v));
})();
